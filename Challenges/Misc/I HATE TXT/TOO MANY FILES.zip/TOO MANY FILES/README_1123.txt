sggCy7+7E0OfkpKjeeHIL9jJnYox2a+ae+C3PS+lHI11edxJdNUzm6Kho/VEDpxf/5zQtF6MB5llqRznmvE4zJpaCbpURfAJiRdD+GDyhYKV2TzcH7gTPrEQui/UJtHlY1buU6yut2H4jW74HvQ7AOGsGEEHdERFqym5HvSdzobIr0FlKd/qkYKhw8IHLh+dDUMniFu8

This is a README file for a project component. It contains non-sensitive sample text.
